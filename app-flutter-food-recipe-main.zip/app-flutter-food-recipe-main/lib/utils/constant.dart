const int animatedBodyMS = 500;
