package com.sangvaleap.food_recipe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
